<?php
    setlocale(LC_ALL,"es_ES"); 
    session_start();
	// Establecemos la conexi�n con la base de datos
    include("../conexion.php");          

?>

<!DOCTYPE html>

<html>
<head>
	<title>Registrarse</title> <!--T�tulo de la p�gina-->
	<link rel="stylesheet" href="../estilo03.css"> <!--Para enlazar archivo css-->
	<style type="text/css" media="screen">
	</style>
	<script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="../js/ejercicio03.js"></script>
</head>

<body>
<div id="contenedor"> <!--contenedor contiene toda la p�gina-->

	<div id="cabecera"> <!--Cabecera-->
	</div>

	<div id="contenido">

		<?php


			//Inicializamos las variables y las variables de error
			$nombreError = $DNIError = $generoError = $edadError = $websiteErr = $apellidos = $contraError = "";
			$nombre = $usuario = $genero = $comment = $website = $apellidosError = $edad = $contra = "";	
			if ($_SERVER["REQUEST_METHOD"] == "POST") {
				if (empty($_POST["nombre"])) {
					$nombreError = "Nombre y apellidos obligatorios";
				} 
				else {
					$nombre = test_input($_POST["nombre"]);
					// Comprobamos que el nombre solo incluya letras y espacios
					if (!preg_match("/^[a-zA-Z ]*$/",$nombre)) {
						$nombreError = "Solo permitido letras y espacios";
					}	
				}
				
				if (empty($_POST["apellidos"])) {
					$apellidosError = "Nombre y apellidos obligatorios";
				} 
				else {
					$apellidos = test_input($_POST["apellidos"]);
					// Comprobamos que el nombre solo incluya letras y espacios
					if (!preg_match("/^[a-zA-Z ]*$/",$apellidos)) {
						$apellidos = "Solo permitido letras y espacios";
					}	
				}
				
				if (empty($_POST["contra"])) {
					$contraError = "Contrase&ntildea obligatoria";
				} 
				else {
					$contra = test_input($_POST["contra"]);	
				}
	  
				if (empty($_POST["usuario"])) {
					$DNIError = "Usuario es obligatorio";
				} 
				else {
					$usuario = test_input($_POST["usuario"]);
				}
			}
		 
			if (isset($_REQUEST['Registrarse']) && $_REQUEST['nombre']!='' && $_REQUEST['apellidos']!='' && $_REQUEST['usuario']!='' && $_REQUEST['contra']!=''){
				$Nombre=$_REQUEST['nombre'];
				$Apellidos=$_REQUEST['apellidos'];                  
				$usuario=$_REQUEST['usuario']; 
				$pass=$_REQUEST['contra'];
		        
				// Nos aseguramos que el DNI (usuario) no se repita
				$resultado = mysqli_query($conexion,"SELECT * from usuarios where Usuario = '$usuario' ");
				
				$rowcount=mysqli_num_rows($resultado);
				if($rowcount==0){
					 if (mysqli_query($conexion, "INSERT INTO usuarios (Nombre,Apellidos,Usuario,Contrasena) VALUES ('$Nombre','$Apellidos','$usuario','$pass')")){
						echo '<script language="javascript">alert("Alta de usuario realizada correctamente");</script>'; 
						//Damos de alta al usuario en la Base de Datos REGISTROS
						$num_fuentes=mysqli_query($conexion, "SELECT * FROM fuentes");
						$rowcount=mysqli_num_rows($num_fuentes);
						$i = 1;
						while($rowcount >= $i){
								$datos_fuentes=mysqli_query($conexion, "SELECT * FROM fuentes where Num = '$i'");
								$datos_f= mysqli_fetch_array($datos_fuentes);
								mysqli_query($conexion, "INSERT INTO registros (Usuario,Sitio) VALUES ('$usuario','$datos_f[1]')");
								$i = $i + 1;
						}
						
					 }
					 else
						 echo '<script language="javascript">alert("Error al realizar el alta de usuario");</script>'; 
				} else{
					 echo '<script language="javascript">alert("El nombre de usuario ya esta ocupado");</script>'; 
				}

			}

			function test_input($data) {
			   $data = trim($data);
			   $data = stripslashes($data);
			   $data = htmlspecialchars($data);
			   return $data;
			}

		?>

		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
			
			<table>
					<tr>
						<td align=right><FONT FACE="verdana">Nombre: </td> 
						<td align=left><input type="text" name="nombre" id="nombre" value="<?php echo $nombre;?>">* <span class="error" id="textoNombre"></span><?php echo $nombreError;?></td>
					</tr>
					<tr>
						<td align=right><FONT FACE="verdana">Apellidos: </td> 
						<td align=left><input type="text" name="apellidos" id="apellidos" value="<?php echo $apellidos;?>">* <span class="error" id="textoApellidos"></span><?php echo $apellidosError;?></td>
					</tr>
					<tr>
						<td align=right><FONT FACE="verdana">Usuario: </td> 
						<td align=left><input type="number_format" name="usuario" id="usuario" value="<?php echo $usuario;?>">* <span class="error" id="textoDNI"></span> <?php echo $DNIError;?></td>
					</tr>
					<tr>
						<td align=right><FONT FACE="verdana">Contrase&ntildea: </td> 
						<td align=left><input type="password" name="contra" id="pass" value="<?php echo $contra;?>">* <span class="error" id="textoPass"></span> <?php echo $contraError;?></td>
					</tr>
					
					<tr>
						<td></td> 
						<td align=left><input type="submit" id="botonEnviar" name="Registrarse" value="Registrarse"></td>				
					</tr>
			</table>
			<p></p>
			<p></p>
			<p></p>
			<table>
					<tr>
						<td></td> 
						<td align=center><FONT FACE="verdana">* Campo obligatorio</td>				
					</tr>
			</table>
		</form>
			
	</div>
	
	<div id="atras">
		<table>
			<tr>
				<td align=left><p class="atras"><a href="../identificacion.php"><img src="../Imagenes/flecha-atras.png"></a>	</a></p></td> 
				<td></td>				
			</tr>
		</table>
	</div>
	
	<div id="pie">
	</div>

</div>
		
</body>


</html>