<?php
    setlocale(LC_ALL,"es_ES"); 
    session_start();
	// Establecemos la conexi�n con la base de datos
	include("../conexion.php");
?>

<!DOCTYPE html>

<html>
<head>
	<title>Baja</title> <!--T�tulo de la p�gina-->
	<link rel="stylesheet" href="../estilo03.css"> <!--Para enlazar archivo css-->
	<style type="text/css" media="screen">
	</style>
</head>

<body>

<div id="contenedor"> <!--contenedor contiene toda la p�gina-->

	<div id="cabecera"> <!--Cabecera-->
	</div>

	<div id="contenido">

		<?php
			
			if(isset($_REQUEST['DarBaja']) && $_REQUEST['usuario']!='' && $_REQUEST['contra']!=''){
				$usuario=$_REQUEST['usuario']; 
				$pass=$_REQUEST['contra'];
				$resultado = mysqli_query($conexion,"SELECT * from usuarios where Usuario = '$usuario' and Contrasena = '$pass' ");
				$rowcount=mysqli_num_rows($resultado);
					if($rowcount==1){	
						if (mysqli_query($conexion, "DELETE FROM usuarios WHERE Usuario='$usuario'") && mysqli_query($conexion, "DELETE FROM registros WHERE Usuario='$usuario'") && mysqli_query($conexion, "DELETE FROM busquedas WHERE Usuario='$usuario'")){
							echo '<script language="javascript">alert("Baja de usuario realizada correctamente");</script>'; ;
						}
				 		else
							echo '<script language="javascript">alert("Error al dar de baja al usuario");</script>'; 
					} else{
						echo '<script language="javascript">alert("Usuario o password incorrectos.");</script>'; 
					}
			}
		?>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
			
			<table id="baja">
				<tr>
					<td align=right><FONT FACE="verdana"> Usuario: </td> 
					<td align=left><input type="number_format" name="usuario" size="15" value=""></td>
				</tr>
				<tr>
					<td align=right><FONT FACE="verdana"> Contrase&ntildea:  </td> 
					<td align=left><input type="password" name="contra" size="15" value=""></td>
				</tr>
				<tr>
					<td></td> 
					<td align=left><input type="submit" name="DarBaja" value="Dar Baja"></td>
				</tr>	
			</table>
			
			<br><br> 
		
		</form>
	
	</div>
	
	<div id="atras">
		<table>
			<tr>
				<td align=left><p class="atras"><a href="../identificacion.php"><img src="../Imagenes/flecha-atras.png"></a>	</a></p></td> 
				<td></td>				
			</tr>
		</table>
	</div>

	<div id="pie">
	</div>

</div>
		
</body>
</html>