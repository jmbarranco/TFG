﻿<?php
	
	// Hacemos la conexión a la base de datos en localhost.
	// Usuario: 01234567
	// Contraseña: administrador
	
	$servername = "localhost";
	$username = "root";
	$password = "josemanuel";
	$database_name = "75482592l";
	
	$conexion = new mysqli($servername, $username, $password ,$database_name)
		or die ("No se ha podido establecer la conexión con la base de datos");

	if (mysqli_connect_errno()) {
	    printf("Connect failed: %s\n", mysqli_connect_error());
	    exit();
	}

?>