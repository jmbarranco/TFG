<?php
	setlocale(LC_ALL,"es_ES");
	session_start();
	$_SESSION['usuario'] = null; //Establecemos los valores a null, cuando el usuario cierre sesion
	$_SESSION['pass'] = null;
	$url="identificacion.php";
	include("./conexion.php");

?>

<!DOCTYPE html>

<html>
<head>
	<title>Identificaci&oacuten</title> <!--T�tulo de la p�gina-->
	<link rel="stylesheet" href="./estilo03.css"> <!--Para enlazar archivo css-->
	<style type="text/css" media="screen">
	</style>
	<script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="../js/ejercicio03.js"></script>
</head>

<body>
<!--Iniciamos las variables a null, para que una vez que el usuario cierre sesion no pueda abrir la pagina principal.php -->

<div id="contenedor"> <!--contenedor contiene toda la p�gina-->

	<div id="cabecera"> <!--Cabecera-->
	</div>
	
	<div id="contenido">

		<div id="formulario">
			<div id="cabeceraformulario">
				
			</div>
			<form action="identificacion.php" method="post" name="identificacion">
				Usuario <br>
				<input type="number_format" name="usuario" size="10" value=""><br><br>
				Password <br>
				<input type="password" name="pass" size="10" value=""><br><br><br>			
				<input type="submit" name="Acceder" value="Acceder" > 

			</form>	
			<div id="pieformulario">
				<a href="./Identificacion/Registrarse.php">Registrarse</a><br>
				<a href="./Identificacion/Baja.php">Darse de baja</a>
			</div>
		</div>


		<?php

		// Comprobamos que se ha enviado el formulario y los dos campos no est�n vac�os.
			
			// Establecemos la conexi�n con la base de datos
							
			if (isset($_REQUEST['Acceder']) && $_REQUEST['usuario']!='' && $_REQUEST['pass']!='') {

				// Calculamos el md5 de la contrase�a.
				$contrasena = md5($_REQUEST['pass']);

				// Realizamos la consulta para comprobar datos y obtenes los valores de las variables de sesi�n.
				$usu=$_REQUEST['usuario'];
				$pass=$_REQUEST['pass'];
				
				$_SESSION['usuario']=($_REQUEST['usuario']);
				$_SESSION['pass']=($_REQUEST['pass']);
				
				$ConsultaNombreDeUsuario = mysqli_query($conexion,"Select Nombre FROM usuarios WHERE Usuario = '$usu'");
				$NombreDeUsuario= mysqli_fetch_array($ConsultaNombreDeUsuario);
				$_SESSION['nombre']=($NombreDeUsuario[0]);
				
				$ConsultaApellidosDeUsuario = mysqli_query($conexion,"Select Apellidos FROM usuarios WHERE Usuario = '$usu'");
				$ApellidosDeUsuario= mysqli_fetch_array($ConsultaApellidosDeUsuario);
				$_SESSION['apellidos']=($ApellidosDeUsuario[0]);
				
				$resultado = mysqli_query($conexion,"Select * FROM usuarios WHERE Usuario = '$usu' AND Contrasena = '$pass' ");
	
				$rowcount=mysqli_num_rows($resultado);
				
				if (mysqli_num_rows($resultado) == 1) {
					$fila = mysqli_fetch_array($resultado);
					// Inicializamos las variables de sesi�n necesarias.	
					header('Location: ./principal.php'); 
				}
				else {
					echo '<script language="javascript">alert("Usuario o password incorrectos");</script>'; 
				}
			}
			
		?>

	</div>

	<div id="pie">
	</div>

</div>

</body>
</html>
