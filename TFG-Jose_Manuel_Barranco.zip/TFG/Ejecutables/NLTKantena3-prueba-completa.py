# -*- coding: utf-8 -*-
__author__ = 'JoseManuelBarranco'
# AÑADIMOS LA PALABRA VACIA M Y GUARDAMOS TODA LA INFORMACION DE LA PAGINA, PARA LUEGO EN LA WEB RESALTAR LA RAIZ
import nltk #Se necesita una version de python mayor de 2.7 (utilizamos 3.2)
nltk.download('punkt') #Descargar diccionario
nltk.download('stopwords') #Descargar diccionario
from nltk.corpus import stopwords
from nltk import word_tokenize
from nltk.data import load
from nltk.stem import SnowballStemmer
from string import punctuation
import re #Para eliminar caracteres especiales
import json
from bs4 import BeautifulSoup
import requests
import csv, operator
import  unicodedata

spanish_stopwords = stopwords.words('spanish')
#Añadimos palabras vacías que quizás no han sido admitidas
spanish_stopwords.insert(0,"d")
spanish_stopwords.insert(1,"m")
#non_words para signos de puntuacion y caracteres especiales
non_words = list(punctuation)
non_words.extend(['¿', '¡','?','!','@','$','€','|','/','%'])
non_words.extend(map(str,range(10)))

urlBase = "http://www.antena3.com/noticias/tecnologia/"
maxPages = 20
counter = 0

def elimina_tildes(s):
   return ''.join((c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c) != 'Mn'))

#Stem

stemmer = SnowballStemmer('spanish')

def stem_tokens(tokens, stemmer):
    stemmed = []
    for item in tokens:
        stemmed.append(stemmer.stem(item))
    return stemmed
i = 0
if i == 0:
    i = i + 1
    lista_terminos = []
    lista_terminosc = []
    contenido_web = []
    lista_frecuencias = []
    lista_definitivac = []
    lista_frecuenciasc = []
    diccionario = {}
    diccionarioc = {}
    lista_terminos_definitiva = []
    palabras_relevantes = []
    palabras_relevantes=["amd","intel","nvidia","nintendo","cpu","actual","version","googl","smartphon","iphon","nuev","sony","telefon","television","bluetooth","artificial","whatsapp","twitter","samsung","acer","galaxy","imagen","pantall","vehicul","coch","aeroupuert","jav","encontr"]
    
    # Construyo la URL
    if i > 1:
        url = "%spage/%d/" %(urlBase,i)

    else:
        url = urlBase
    contador_pag = 0
    # Realizamos la petición a la web
    req = requests.get(url)
    # html = req.text.encode('utf-8').decode('ascii', 'ignore')
    # Comprobamos que la petición nos devuelve un Status Code = 200
    statusCode = req.status_code
    if statusCode == 200:

        # Pasamos el contenido HTML de la web a un objeto BeautifulSoup()
       	html = BeautifulSoup(req.text,"lxml")
	# Obtenemos todos los divs donde estan las entradas
        entradas = html.find_all('li',{'class':'listado-item'})
	print contador_pag
	contador_pag = contador_pag + 1
	# Abrimos el archivo para guardar la salida de los datos de la fuente
	f = open('../Contenidos/contenidoweb4', 'w')
	f1 = open('../Novedades/Informacion4', 'w')
	f2 = open('../Frecuencias/frecuencias4', 'w')
	f3 = open('../Novedades/contenidowebc4', 'w')
        # Recorremos todas las entradas para extraer el texto
        for entrada in entradas:
	    try:
            	texto = entrada.find('div', {'class' : 'cuerpo-noticia'}).getText()
	    except AttributeError:
		print "La información de esta noticia no se ha podido recuperar"
	    
	#0-Eliminamos los caracteres especiales y signos de puntuacion
	    texto = ''.join([c for c in texto if c not in non_words])
	    texto = texto.strip('\t\r\n')
	  
	#1-Tokenizamos el texto
	    tokens = nltk.word_tokenize(texto)
			
	#2-Eliminamos las palabras vacias del texto
	    content = [w for w in tokens if w.lower() not in spanish_stopwords]
		
	#3-Extraemos la raiz de las palabras
	    stems = stem_tokens(content, stemmer)	  
    	    contador = 0
	    contadorc = 0

	#4-Contamos y ordenamos por frecuencias de las palabras
	#Creamos dos listas: lista_terminos -> Términos | lista_frecuencias-> Frecuencia
	        
	    json.dump(tokens, f)
	    json.dump("<br>",f)
	    #PRIMERO lo hacemos para el contenido web sin raiz
	    for conten in content:		
		if len(lista_terminosc) == 0:
			lista_terminosc.insert(contadorc,conten)
			lista_frecuenciasc.insert(contadorc, 1)
			contadorc = contadorc + 1
			
		else:
			if conten in lista_terminosc:
				if conten in palabras_relevantes: 				
					valor = lista_frecuenciasc[lista_terminosc.index(conten)]				
					lista_frecuenciasc[lista_terminosc.index(conten)] = valor + 2
				else:
					valor = lista_frecuenciasc[lista_terminosc.index(conten)]				
					lista_frecuenciasc[lista_terminosc.index(conten)] = valor + 1
			else:
				if conten in palabras_relevantes:
					lista_terminosc.insert(contadorc,conten);
					lista_frecuenciasc.insert(contadorc,2);
					contadorc = contadorc + 1
				else: 
					lista_terminosc.insert(contadorc,conten);
					lista_frecuenciasc.insert(contadorc,1);
					contadorc = contadorc + 1
	    
	    #SEGUNDO para el contenido contando la raiz
	    for stem in stems:
		if len(lista_terminos) == 0:
			lista_terminos.insert(contador,stem)
			lista_frecuencias.insert(contador, 1)
			contador = contador + 1
			
		else:
			if stem in lista_terminos:
				if stem in palabras_relevantes: 				
					valor = lista_frecuencias[lista_terminos.index(stem)]				
					lista_frecuencias[lista_terminos.index(stem)] = valor + 2
				else:
					valor = lista_frecuencias[lista_terminos.index(stem)]				
					lista_frecuencias[lista_terminos.index(stem)] = valor + 1
			else:
				if stem in palabras_relevantes:
					lista_terminos.insert(contador,stem);
					lista_frecuencias.insert(contador,2);
					contador = contador + 1
				else: 
					lista_terminos.insert(contador,stem);
					lista_frecuencias.insert(contador,1);
					contador = contador + 1

	cont = 0
	for t in lista_terminos:
	    	diccionario[lista_terminos[cont]] = lista_frecuencias[cont]
		cont = cont + 1
        contc = 0
	for t in lista_terminosc:
	    	diccionarioc[lista_terminosc[contc]] = lista_frecuenciasc[contc]
		contc = contc + 1

	lista_diccionario = diccionario.items()
	lista_diccionario.sort(key=lambda x: x[1],reverse=True) #Reverse para ordenar de mayor a menor frecuencia

        lista_diccionarioc = diccionarioc.items()
	lista_diccionarioc.sort(key=lambda x: x[1],reverse=True) #Reverse para ordenar de mayor a menor frecuencia
	
	json.dump(lista_diccionarioc,f3)

    #map_frecuencia = map(cuenta_frecuencia,lista1,lista2)	    
	print lista_diccionario
	#5-Almacenamos las 20 palabras más relevantes	
	k = 0
	while k < 20:
		palabra = lista_diccionario[k][0]
		lista_terminos_definitiva.insert(k,palabra)
		k += 1    	    
	
	#6- Con dump de json creamos el archivo y almacenamos los datos que extraemos
	json.dump(lista_terminos_definitiva, f1)	
	json.dump(lista_diccionario,f2)

