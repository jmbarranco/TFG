#!/bin/bash

python NLTKciencia-prueba-completa.py
python NLTKxataka-prueba-completa.py
python NLTKantena3-prueba-completa.py
python NLTKabc-prueba-completa.py
python NLTKEspacenet\=Tecnology-prueba-completa.py
python NLTKMIT-CSAIL-prueba-completa.py
python NLTKUGR\=Tecnologia-prueba-completa.py
