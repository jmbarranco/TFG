<?php
    setlocale(LC_ALL,"es_ES"); 
    session_start();
	include("./conexion.php");
	$hora = time();
	require_once("./session_principal.php");
?>

<!DOCTYPE html>

<html>
<head>

<?php 
$NombreUsuario="".$_SESSION['nombre']." ".$_SESSION['apellidos']."";
$usuario = $_SESSION['usuario'];
?>

<script>
function funcionphp(){
	alert('Sesion cerrada');
}
	
</script>
	
	
	<title>SVT</title> <!--T�tulo de la p�gina-->
	
	<link rel="stylesheet" href="./estilo-principal.css"> <!--Para enlazar archivo css-->
	<style type="text/css" media="screen">
	</style>
	<script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="../js/ejercicio03.js"></script>
</head>

<body>
<div id="contenedor"> <!--contenedor contiene toda la p�gina-->

	<div id="cabecera"> <!--Cabecera-->
	</div>

	<div id="contenido">
		
		<div id="sub_cabecera">
			<table id="bienvenida">
					<tr>
						<td align=left><p><b> Bienvenido, <?php echo $NombreUsuario ?></b></p></td> 		
						<td align=right><i><?php echo date(" d/m/Y (H:i:s)  ", $hora); ?></i></td>
					</tr>
				</table>
				
				<table id="eleccion_tema">
					<tr>
						 <form>
							  <td id="eleccion_tema"><input type="radio" name="opcion" value="Tecnologia" checked> Tecnologia</td>
							  <td id="eleccion_tema"><input type="submit" id="botonEnviar" name="Seleccionar" value="Seleccionar"></td>
						</form> 
					</tr>
				</table>
		</div>
		
		<div id="contiene_principal">
		
			<div id="contenido_derecha">
							<?php 
						//Primero cargamos el numero de fuentes (para los tags)
						$numero_fuente = mysqli_query($conexion,"SELECT * from fuentes");
						$rowcount=mysqli_num_rows($numero_fuente);
						$vector_tag=array();
						//Comprobamos la eleccion
						if (isset($_REQUEST['Seleccionar'])){
							$Opcion=$_REQUEST['opcion']; 
							if($Opcion=="Tecnologia"){?>
								<table id="tabla1">
									<tr>
										<td id="fuente_informacion" align=center><b> Fuente de informacion </b></td> 
										<td id="novedades" align=center><b> Novedades </b></td>
										<td id="fuente_informacion" align=center><b> Contenido web </b></td>						
									</tr>
									<tr>
									<?php 			
												//Comprobamos si hay algun dato insertado previamente o si hay que actualizar
												//Extramos cuantas fuentes hay y los datos de dichas fuentes
															$i = 1;
															$numero_fuente = mysqli_query($conexion,"SELECT * from fuentes");
															$rowcount=mysqli_num_rows($numero_fuente);
															$contador_tag = 0; //Contador para almacenar el termino y frecuencia del tag
															
															while($rowcount >= $i){
																$Nombre_fichero = "./Novedades/Informacion";
																$fp = fopen($Nombre_fichero.=$i, "r");
																	$linea = "";
																	while(!feof($fp)) {
																		$linea .= fgets($fp);
																	}
																
																$cont_web = "./Contenidos/contenidoweb";
																$fp1 = fopen($cont_web.=$i, "r");
																	$linea1 = "";
																	while(!feof($fp1)) {
																		$linea1 .= fgets($fp1);
																	}
																
																fclose($fp);
																fclose($fp1);
																
																//Limpiamos las novedades y el contenido web
																$linea=str_replace("\u00f1","n", $linea); //Sustituimos el codigo de � por n
																$linea=str_replace("\u00cd","i", $linea); //Sustituimos el codigo de �
																$linea=str_replace("\u2026","", $linea); //Sustituimos el codigo de ...
																$linea=str_replace("\u2014","", $linea); //Sustituimos el codigo de --
																$linea=str_replace("\u00c1","a", $linea); //Sustituimos el codigo de �
																$linea=str_replace("\u00fc","u", $linea); //Sustituimos el codigo de �
																$linea=str_replace("\u00c9","e", $linea); //Sustituimos el codigo de �
																$linea=str_replace("\u00a1","", $linea); //Sustituimos el codigo de �
																$linea=str_replace("\u00ab","", $linea); //Sustituimos el codigo de <<
																$linea=str_replace("\u00bf","", $linea); //Sustituimos el codigo de �
					//											$linea=str_replace("\"","", $linea); //SUSTITUIMOS LAS COMILLAS POR ASTERISCOS PARA LUEGO PARSEAR LAS PALABRAS
																$linea=str_replace("[","", $linea); //SUSTITUIMOS LOS CORCHETES 
																$linea=str_replace("]","", $linea); //SUSTITUIMOS LOS CORCHETES 
																$linea=str_replace(",","", $linea); //SUSTITUIMOS LAS COMAS 
																$linea=str_replace("u00bf","", $linea); //SUSTITUIMOS LA INTERROGACION
																$linea=str_replace("u201c","", $linea); //SUSTITUIMOS LA COMILLA DOBLE EN CODIGO 
																$linea=str_replace("u2018","", $linea); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
																$linea=str_replace("u2019","", $linea); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
																$linea=str_replace("u00f1","n", $linea); //SUSTITUIMOS LA � EN CODIGO
																$linea=str_replace("u00a1","", $linea); //SUSTITUIMOS LA � EN CODIGO
																$linea=str_replace("u201d","", $linea); //SUSTITUIMOS LA �� EN CODIGO
																$linea=str_replace("u00bb","", $linea); //SUSTITUIMOS LA >> EN CODIGO
																$linea=str_replace("u00e8","e", $linea); //SUSTITUIMOS LA � EN CODIGO
																
																$linea1=str_replace("\u00bb","", $linea1); //Sustituimos el codigo de >>
																$linea1=str_replace("\u2014","", $linea1); //Sustituimos el codigo de --																
																$linea1=str_replace("\u2026","", $linea1); //Sustituimos el codigo de ...
																$linea1=str_replace("\u00c1","A", $linea1); //Sustituimos el codigo de �
																$linea1=str_replace("\u00c9","E", $linea1); //Sustituimos el codigo de �
																$linea1=str_replace("\u00cd","I", $linea1); //Sustituimos el codigo de �
																$linea1=str_replace("\u00a1","", $linea1); //Sustituimos el codigo de �
																$linea1=str_replace("\u00ab","", $linea1); //Sustituimos el codigo de <<
																$linea1=str_replace("\u00fc","u", $linea1); //Sustituimos el codigo de �
																$linea1=str_replace("\u00bf","", $linea1); //Sustituimos el codigo de �
																$linea1=str_replace("[","", $linea1); //SUSTITUIMOS LOS CORCHETES 
																$linea1=str_replace("]","", $linea1); //SUSTITUIMOS LOS CORCHETES 
																$linea1=str_replace(",","", $linea1); //SUSTITUIMOS LAS COMAS 
																$linea1=str_replace("u00bf","", $linea1); //SUSTITUIMOS LA INTERROGACION
																$linea1=str_replace("u201c","", $linea1); //SUSTITUIMOS LA COMILLA DOBLE EN CODIGO 
																$linea1=str_replace("u2018","", $linea1); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
																$linea1=str_replace("u2019","", $linea1); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
																$linea1=str_replace("u00e1","a", $linea1); //SUSTITUIMOS LA � EN CODIGO
																$linea1=str_replace("u00e9","e", $linea1); //SUSTITUIMOS LA � EN CODIGO
																$linea1=str_replace("u00ed","i", $linea1); //SUSTITUIMOS LA � EN CODIGO
																$linea1=str_replace("u00f3","o", $linea1); //SUSTITUIMOS LA � EN CODIGO
																$linea1=str_replace("u00fa","u", $linea1); //SUSTITUIMOS LA � EN CODIGO
																$linea1=str_replace("u201d","", $linea1); //SUSTITUIMOS LA �� EN CODIGO
																$linea1=str_replace("u00bb","", $linea1); //SUSTITUIMOS LA >> EN CODIGO
																$linea1=str_replace("u00e8","e", $linea1); //SUSTITUIMOS LA � EN CODIGO
																//Actualizamos las fuentes
																mysqli_query($conexion,"UPDATE fuentes SET Novedades ='$linea' WHERE Num = '$i'");
																mysqli_query($conexion,"UPDATE fuentes SET contenidoweb ='$linea1' WHERE Num = '$i'");
																
																//Ahora vamos a comprobar si hay novedades con respecto al anterior registro
																
																$datos_fuente = mysqli_query($conexion,"SELECT * from fuentes where Num = '$i' ");
																$datos= mysqli_fetch_array($datos_fuente);
																$num_fuente = $datos[0];
																$nombre_fuente= $datos[1];
																$novedades_fuente= $datos[2];
																$url_fuente= $datos[3];
																$contenido_fuente = "./Principal/contenidoweb.php";
																$novedades_registro = mysqli_query($conexion,"SELECT Novedades from registros where Sitio = '$nombre_fuente' and Usuario = '$usuario'");
																$rowcount1=mysqli_num_rows($novedades_registro);
																$Novedades_es_igual= mysqli_fetch_array($novedades_registro);
																$salida = $Novedades_es_igual[0];
																
																$porciones = explode("\"", $novedades_fuente); //Dividimos el texto cada caracter
																$contador = 1;
																$longitud = count($porciones);
																
																//Extraemos las frecuencias del contenido web sin raiz
																$Nombre_ficherosr = "./Novedades/contenidowebc";
																$fp = fopen($Nombre_ficherosr.=$i, "r");
																$lineasr = "";
																
																while(!feof($fp)) {
																	$lineasr .= fgets($fp);
																}
																//Tratamos el texto para eliminar caracteres raros
																$lineasr=str_replace("\u00bb","", $lineasr); //Sustituimos el codigo de >>
																$lineasr=str_replace("\u2014","", $lineasr); //Sustituimos el codigo de --																
																$lineasr=str_replace("\u2026","", $lineasr); //Sustituimos el codigo de ...
																$lineasr=str_replace("\u00c1","A", $lineasr); //Sustituimos el codigo de �
																$lineasr=str_replace("\u00c9","E", $lineasr); //Sustituimos el codigo de �
																$lineasr=str_replace("\u00cd","I", $lineasr); //Sustituimos el codigo de �
																$lineasr=str_replace("\u00a1","", $lineasr); //Sustituimos el codigo de �
																$lineasr=str_replace("\u00ab","", $lineasr); //Sustituimos el codigo de <<
																$lineasr=str_replace("\u00fc","u", $lineasr); //Sustituimos el codigo de �
																$lineasr=str_replace("\u00bf","", $lineasr); //Sustituimos el codigo de �
																$lineasr=str_replace("[","", $lineasr); //SUSTITUIMOS LOS CORCHETES 
																$lineasr=str_replace("]","", $lineasr); //SUSTITUIMOS LOS CORCHETES 
																$lineasr=str_replace(",","", $lineasr); //SUSTITUIMOS LAS COMAS 
																$lineasr=str_replace("\u00bf","", $lineasr); //SUSTITUIMOS LA INTERROGACION
																$lineasr=str_replace("\u201c","", $lineasr); //SUSTITUIMOS LA COMILLA DOBLE EN CODIGO 
																$lineasr=str_replace("\u2018","", $lineasr); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
																$lineasr=str_replace("\u2019","", $lineasr); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
																$lineasr=str_replace("\u00e1","a", $lineasr); //SUSTITUIMOS LA � EN CODIGO
																$lineasr=str_replace("\u00e9","e", $lineasr); //SUSTITUIMOS LA � EN CODIGO
																$lineasr=str_replace("\u00ed","i", $lineasr); //SUSTITUIMOS LA � EN CODIGO
																$lineasr=str_replace("\u00f3","o", $lineasr); //SUSTITUIMOS LA � EN CODIGO
																$lineasr=str_replace("\u00fa","u", $lineasr); //SUSTITUIMOS LA � EN CODIGO
																$lineasr=str_replace("\u00f1","n", $lineasr); //SUSTITUIMOS LA � EN CODIGO
																	
																$porciones_lineasr = explode("\"", $lineasr); //Dividimos el texto cada caracter
																$contador1 = 1;
																$longitud1 = count($porciones_lineasr);
																
																//Almacenamos el termino y la frecuencia de los dos primeros terminos para los TAGS
															
																$vector_tag[$contador_tag] = $porciones_lineasr[1]; //Primer termino
																$contador_tag = $contador_tag + 1;
																$vector_tag[$contador_tag] = $porciones_lineasr[2]; //frecuencia primer termino
																$contador_tag = $contador_tag + 1;
																$vector_tag[$contador_tag] = $porciones_lineasr[3]; //segundo termino
																$contador_tag = $contador_tag + 1;
																$vector_tag[$contador_tag] = $porciones_lineasr[4]; //frecuencia segundo termino
																$contador_tag = $contador_tag + 1;
																while($contador < $longitud-1){
																	
																	$findme = $porciones[$contador];
																	$esta = false;
																	$contador1 = 1;
																		
																	while($contador1 < $longitud1 and $esta===false){
																	
																		$pos = stripos($porciones_lineasr[$contador1], $findme);
																
																		if($pos!==false){ //Esta 
																			$esta = true;
																			$porciones[$contador] = $porciones_lineasr[$contador1];
																			$porciones_lineasr[$contador1] = " "; //Lo eliminamos para que el termino no se vuelva a repetir
																			//echo "Esta!";
																				
																		}
																		else {$contador1 = $contador1 + 2;}
																		}
																		
																	$contador = $contador + 2; //Puesto que solo contiene terminos los puestos impares
																	
																	
																}
																
																if(strcmp($salida, $novedades_fuente) == 0){?>
																	<tr>
																		<td id="fuentes" align=center><b><a href="<?php echo $url_fuente?>"> <?php echo $nombre_fuente ?></b></a></td> 
																		<td id="novedad" align=left> <?php 
																		$j=1;
																		while($j < $longitud-1){
																			echo $porciones[$j];
																			$j = $j + 1;
																		}?></td>
																		<td id="fuentes" align=center><a href="<?php echo $contenido_fuente?>"><img src="./Imagenes/contenidoweb.png" ></a></td>
																	</tr>
																	<?php
																}
																else{
																	?>
																	<tr>
																		<td id="fuentes_actualizacion" align=center><b><a href="<?php echo $url_fuente?>"> <?php echo $nombre_fuente ?> </b></a></td> 
																		<td id="novedad_actualizacion" align=left> <?php 
																		$j=1;
																		while($j < $longitud-1){
																			echo $porciones[$j];
																			$j = $j + 1;
																		}
																		
																		?></td>
																		<td id="fuentes_actualizacion" align=center><a href="<?php echo $contenido_fuente?>"><img src="./Imagenes/contenidoweb.png" > </a></td>
																	</tr><?php
																}
																if($rowcount1 == 0) //SI EL USUARIO NO TIENE REGISTRO DE ESA FUENTE, A�ADIMOS, SI NO , ACTUALIZAMOS
																		mysqli_query($conexion, "INSERT INTO registros (Usuario,Sitio,Novedades) VALUES ('$usuario','$nombre_fuente','$linea')");
																else
																		mysqli_query($conexion, "UPDATE registros SET Novedades ='$linea' WHERE Sitio = '$nombre_fuente' and Usuario = '$usuario'");
																
																
																$i = $i + 1;
															}
										
										?>
										
														
									</tr>
								</table>		
						<?php
							}
						}?>
			</div>
			<div id="menu_izq_global">			
		
				<div id="menu_izq">
					<p align=center><a id="a1" href="./Principal/modificar.php" ><img src="./Imagenes/icono-perfil.png"><b> Modificar perfil </a></img></b></p>
				</div>
				<div id="menu_izq">
					<p align=center><a href="./Principal/buscar.php" ><img src="./Imagenes/lupa-buscar.png"><b> Buscar  </a></b></img></p>
				</div>
				<div id="menu_izq">
					<p align=center><a href="./Principal/tendencias.php" ><img src="./Imagenes/grafica.png"><b> Tendencias  </a></b></img></p>
				</div>
				<?php
				if (isset($_REQUEST['Seleccionar'])){?>
					<div id="TAG">
						
						<div id="cabecera_TAG">
						</div>
						
						<ul>
							
							<?php $j = 0;
							
							while($j < $rowcount*2){ //*2 porque almacenamos 2 terminos + 2 frecuencas de cada fuente
								if($vector_tag[$j*2+1] <= 3){//Si la frecuencia es menor que 3, utilizamos tag1?>  
									<li class="tag1"><a href="#<?php echo $vector_tag[$j*2];?>"><?php echo $vector_tag[$j*2];?></a></li>
									<?php
								}
								if($vector_tag[$j*2+1] == 4){?>
									<li class="tag1"><a href="#<?php echo $vector_tag[$j*2];?>"><?php echo $vector_tag[$j*2];?></a></li>
									<?php
								}
								if($vector_tag[$j*2+1] == 5){?>
									<li class="tag2"><a href="#<?php echo $vector_tag[$j*2];?>"><?php echo $vector_tag[$j*2];?></a></li>
									<?php
								}
								if($vector_tag[$j*2+1] == 6){?>
									<li class="tag3"><a href="#<?php echo $vector_tag[$j*2];?>"><?php echo $vector_tag[$j*2];?></a></li>
									<?php
								}
								if($vector_tag[$j*2+1] == 7){?>
									<li class="tag4"><a href="#<?php echo $vector_tag[$j*2];?>"><?php echo $vector_tag[$j*2];?></a></li>
									<?php
								}
								if($vector_tag[$j*2+1] > 7){?>
									<li class="tag5"><a href="#<?php echo $vector_tag[$j*2];?>"><?php echo $vector_tag[$j*2];?></a></li>
									<?php
								}
								
								$j = $j + 1;
							}?>
					  </ul>
					  
					</div>
				</div>
				<?php } ?>
		</div>
		
		
		
		<?php	/*
			$usu = $_SESSION['usuario'];
			$pass = $_SESSION['pass'];
			
			$resultado = mysqli_query($conexion,"Select * FROM usuarios WHERE Usuario = '$usu' AND Contrasena = '$pass' ");
			$rowcount=mysqli_num_rows($resultado);
			if (mysqli_num_rows($resultado) == 0) { //El usuario intenta acceder a principal sin identificarse
				header('Location: ./identificacion.php'); //Redireccionamos a identificacion.php
			} 
			// Establecemos la conexi�n con la base de datos
     		include("./conexion.php");          
			*/
		?>
			
	</div>
	
	<div id="atras">
		<table>
			<tr>
				<td align=left><p class="atras"><a href="./identificacion.php" onClick="funcionphp()"><img src="./Imagenes/cerrar-sesion.png" ></a></p></td> 
				<td></td>				
			</tr>
		</table>
	</div>
	
	<div id="pie">
	</div>

</div>
		
</body>


</html>