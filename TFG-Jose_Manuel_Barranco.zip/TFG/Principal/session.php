<?php
if(!isset($_SESSION['usuario']) !="0") {
	header('Location: ../Identificacion/identificacion_error.php');
}
?>