<?php
    setlocale(LC_ALL,"es_ES"); 
    session_start();
	include("../conexion.php");
	$NombreUsuario="".$_SESSION['nombre']." ".$_SESSION['apellidos']."";
	$usuario = $_SESSION['usuario'];
	$hora = time();
	require_once("./session.php");
?>

<!DOCTYPE html>

<html>
<head>
	
	<title>SVT</title> <!--T�tulo de la p�gina-->
	
	<link rel="stylesheet" href="../estilo-principal.css"> <!--Para enlazar archivo css-->
	<style type="text/css" media="screen">
	</style>
	<script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="../js/ejercicio03.js"></script>
</head>

<body>
<div id="contenedor"> <!--contenedor contiene toda la p�gina-->

	<div id="cabecera"> <!--Cabecera-->
	</div>

	<div id="contenido">
		
		<table id="bienvenida">
			<tr>
				<td align=left><p><b> Bienvenido, <?php echo $NombreUsuario ?></b></p></td> 		
				<td align=right><i><?php echo date(" d/m/Y (H:i:s)  ", $hora); ?></i></td>
			</tr>
		</table>
		
		<table id="eleccion_sitio">
			<tr>
				<form> 
						<td align=right> <?php echo "Introduzca una busqueda: "?><td>
						<td align=left><input type="text" name="buscar" id="buscar" value=""></td>
						<td align=left><input type="submit" id="botonbuscar" name="botonbuscar" value="Buscar"></td>
				</form> 
			</tr>
		</table>
		
		<?php 
		
		//Comprobamos la eleccion		
		$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes");
		$rowcount=mysqli_num_rows($paginas);
		$frecuencias = array();
		$busqueda;
		$i = 1;
		$resultados = 0; //resultados de la busqueda
		
		//A�adimos el termino a la tabla de busquedas
		
		if (isset($_REQUEST['botonbuscar'])){

				$busqueda=$_REQUEST['buscar'];
				$consulta_busqueda = mysqli_query($conexion,"SELECT * from busquedas where Termino='$busqueda' and Usuario='$usuario'");
				$paginas_vec= mysqli_fetch_array($consulta_busqueda);
				$rowcount_busqueda=mysqli_num_rows($consulta_busqueda);

				if(!empty($busqueda)){ //Si no esta vacia, insertamos o actualizamos
					if($rowcount_busqueda == 0){ //No se ha encontrado ese termino con ese usuario, por lo que lo a�adimos
							mysqli_query($conexion, "INSERT INTO busquedas (Usuario,Termino,Frecuencia) VALUES ('$usuario','$busqueda',1)");
					}
					else{ //Se ha encontrado el termino y el usuario, aumentamos en 1 la frecuencia
						$consulta_termino = mysqli_query($conexion,"SELECT Frecuencia from busquedas where Termino='$busqueda' and Usuario='$usuario'");
						$freq_termino_vec= mysqli_fetch_array($consulta_termino);
						$freq_termino_vec[0] = $freq_termino_vec[0] + 1;
						mysqli_query($conexion, "UPDATE busquedas SET Frecuencia ='$freq_termino_vec[0]' WHERE Termino = '$busqueda' and Usuario = '$usuario'");
					}
				}
		}
	
	
		//Buscamos el termino en todas las fuentes
		while($i <= $rowcount){
			$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes where Num=$i");
			$paginas_vec= mysqli_fetch_array($paginas);
								
			if (isset($_REQUEST['botonbuscar'])){
				$busqueda=$_REQUEST['buscar']; 
				
				$vec_busqueda = explode(" ", $busqueda); //Dividimos el texto cada caracter
				$elem_busqueda = count($vec_busqueda);
					$cont_web = mysqli_query($conexion,"SELECT contenidoweb from fuentes where Sitio='$paginas_vec[0]'");
					$cont_web_vec = mysqli_fetch_array($cont_web);
					$texto_sin_comillas=str_replace("\"","*", $cont_web_vec[0]); //SUSTITUIMOS LAS COMILLAS POR ASTERISCOS PARA LUEGO PARSEAR LAS PALABRAS
					$texto_sin_comillas=str_replace("[","", $texto_sin_comillas); //SUSTITUIMOS LOS CORCHETES 
					$texto_sin_comillas=str_replace("]","", $texto_sin_comillas); //SUSTITUIMOS LOS CORCHETES 
					$texto_sin_comillas=str_replace(",","", $texto_sin_comillas); //SUSTITUIMOS LAS COMAS 
					$texto_sin_comillas=str_replace("u00bf","", $texto_sin_comillas); //SUSTITUIMOS LA INTERROGACION
					$texto_sin_comillas=str_replace("u201c","", $texto_sin_comillas); //SUSTITUIMOS LA COMILLA DOBLE EN CODIGO 
					$texto_sin_comillas=str_replace("u2018","", $texto_sin_comillas); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					$texto_sin_comillas=str_replace("u2019","", $texto_sin_comillas); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					$texto_sin_comillas=str_replace("u00f1","n", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00a1","", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					
					
					$texto_sin_comillas=str_replace("u00e1","a", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00e9","e", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00c9","e", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00ed","i", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00f3","o", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00fa","u", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					
					//Seleccionamos las palabras relevantes
					$relv_web = mysqli_query($conexion,"SELECT Novedades from fuentes where Sitio='$paginas_vec[0]'");
					$relv_web_vec = mysqli_fetch_array($relv_web);
					$texto_sin_comillas1=str_replace("\"","*", $relv_web_vec[0]); //SUSTITUIMOS LAS COMILLAS POR ASTERISCOS PARA LUEGO PARSEAR LAS PALABRAS
					$texto_sin_comillas1=str_replace("[","", $texto_sin_comillas1); //SUSTITUIMOS LOS CORCHETES 
					$texto_sin_comillas1=str_replace("]","", $texto_sin_comillas1); //SUSTITUIMOS LOS CORCHETES 
					$texto_sin_comillas1=str_replace(","," ", $texto_sin_comillas1); //SUSTITUIMOS LAS COMAS 
					$texto_sin_comillas1=str_replace("u00bf","", $texto_sin_comillas1); //SUSTITUIMOS LA INTERROGACION
					$texto_sin_comillas1=str_replace("u201c","", $texto_sin_comillas1); //SUSTITUIMOS LA COMILLA DOBLE EN CODIGO 
					$texto_sin_comillas1=str_replace("u2018","", $texto_sin_comillas1); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					$texto_sin_comillas1=str_replace("u2019","", $texto_sin_comillas1); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					
					$porciones = explode("*", $texto_sin_comillas); //Dividimos el texto cada caracter
					
					$porciones1 = explode("*", $texto_sin_comillas1); //Dividimos el texto cada caracter
							
					$cont = 0;
					$cont1 = 0;
					
					$longitud = count($porciones);
					$longitud1 = count($porciones1);
					$esta = false;
					$frecuencia = 0;
					$frecuencias[$i-1] = 0;
					
					while($cont1 < $elem_busqueda){ //Recorremos los elementos de la busqueda
						$frecuencia = 0;
						$cont = 0;
						$elem = $vec_busqueda[$cont1]; //elem es cada una de las palabras de la busqueda

						while($cont < $longitud-1){ //Para cada elemento, buscamos si esta en el contenido web
							
							$esta = false;
							if(empty($porciones[$cont])){//Si esta vacio, pasamos
								$cont = $cont + 1;
							}
							else{
								$findme = $elem;
								$pos = stripos($porciones[$cont], $findme);
																	
								if($pos!==false){ //Esta en las relevantes
									$esta = true;
									$frecuencia = $frecuencia + 1;
								}
								$cont = $cont + 1;
																	
							}
						}
						$pos = ($i - 1);
						//echo $frecuencia;
						$frecuencias[$pos] = $frecuencias[$pos] + $frecuencia; //Sumar todas las frecuencias de los terminos			
						$resultados += $frecuencia;
						$cont1 = $cont1 + 1;
					}
	
				
				
				
				}
			$i = $i + 1;
			}
			if (isset($_REQUEST['botonbuscar'])){ //Mostramos la tabla con las paginas mas relevantes
			
				?>
				<table id="muestra_busqueda">
					<tr>
						<td>Mostrando los resultados a la busqueda: <?php echo $busqueda ?> (<?php echo $resultados;?> resultados)</td>
					</tr>
				</table>
				<?php 
				$frecuencias_ordenado = $frecuencias;
				
				rsort($frecuencias_ordenado); // Ordnamos las frecuencias de mayor a menor
				
				
				$paginas_ordenadas = array(); //En paginas ordenadas almacenamos la posicion de las paginas mas relevantes
				$longitud = $rowcount;

				$contador1 = 0; //Contador para el vector ordenado
				$contador2 = 0; //Contador para vector normal
				while($contador1 < $longitud){
					
					
					while($frecuencias[$contador2]===NULL){
							$contador2 = $contador2 + 1;
					}
				
					if($frecuencias_ordenado[$contador1]==$frecuencias[$contador2]){
							array_push($paginas_ordenadas, $contador2 + 1); //+1 para almacenar el Num de la pagina, no la posicion (0 no existe)
							$frecuencias[$contador2] = -1; //Establecemos un -1 para que en esa posicion nunca sea igual y poder mantener intacta la posicion del array
							$contador1 = $contador1 + 1;
							$contador2 = 0;
					}
					else{
						$contador2 = $contador2 + 1;
					}
					
				}
				
				//Mostramos las paginas mas relevantes
				$i = 0;
				
				?> <table id="tabla_busqueda">
					<tr>
						<td id="tabla_busqueda1" align=center><b> Fuente de informacion </b></td>
						<td id="tabla_busqueda_resultados1" align=center><b> Resultados </b></td>
					</tr><?php
				while($i < $rowcount){
						$num_pag = $paginas_ordenadas[$i];
						$datos_fuente = mysqli_query($conexion,"SELECT * from fuentes where Num = '$num_pag' ");
						$datos= mysqli_fetch_array($datos_fuente);
						?>
						<tr>
							<td id="tabla_busqueda2" align=center><a href="<?php echo $datos[3]?>"><b><?php echo $datos[1]?></b></a></td>
							<td id="tabla_busqueda_resultados" align=center><b> <?php echo $frecuencias_ordenado[$i];?> </b></td>
						</tr>
						
				
					<?php $i = $i + 1;
				}?>
				</table>												
	<?php	
	
			//MOSTRAMOS LAS SUGERENCIAS
	?>
			<table id="muestra_sugerencia">
					<tr>
						<td>Sugerencias:</td>
					</tr>
			</table>
	<?php 
			//Seleccionamos los 5 terminos mas frecuentes del usuario
			
			$terminos_frecuentes = mysqli_query($conexion,"SELECT Termino from busquedas where Usuario='$usuario' ORDER BY Frecuencia DESC");
			$term_freq_vec = mysqli_fetch_array($terminos_frecuentes);
			$numero_terminos=mysqli_num_rows($terminos_frecuentes);
			$j = 0;
			
			if($numero_terminos > 5){ //Si el numero de terminos del usuario es mayor que 5, solo cogemos los 5 primeros

				//Solo nos interesan los 5 primeros terminos mas frecuentes	
				
				while($j < 5){
					$terminos_frecuentes_ord[$j]=$term_freq_vec[0];
					$term_freq_vec = mysqli_fetch_array($terminos_frecuentes);
					$j = $j + 1;
				}
			}
			else{ //El usuario ha realizado menos de 5 busquedas, cogemos las que haya realizado
				while($j < $numero_terminos){
					$terminos_frecuentes_ord[$j]=$term_freq_vec[0];
					$term_freq_vec = mysqli_fetch_array($terminos_frecuentes);
					$j = $j + 1;
				}
			}
			
			//Recorremos todas las fuentes para extraer el contenido web y buscar las sugerencias
			$i = 1;?>
			<table id="muestra_sugerencias">
					

			<?php
			while($i <= $rowcount){
				
				$contenido_web = mysqli_query($conexion,"SELECT contenidoweb from fuentes where Num='$i' ");
				$cont_web = mysqli_fetch_array($contenido_web);
				$cont_web1=str_replace("\"","*", $cont_web[0]); //Sustituimos para poder parsear el texto (pasar de vector a string)
				$contenido_web_porciones = explode("*", $cont_web1); //Dividimos el texto cada caracter
				$longitud_cont_web = count($contenido_web_porciones);
				$contador = 1;
				
				while($contador < $longitud_cont_web-1){
					
					if($numero_terminos >= 5 ){ //Si el usuario tiene menos de 5 terminos frecuentes, no se hacen sugerencias (pueden ser demasiadas)
					
						if($contador >= 3 and $contador <= $longitud_cont_web-5){
							//Si el termino anterior y el actual pertenecen a algunos de los terminos frecuentes buscados, se muestran
							if( ((stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[0])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[1]) !==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[2])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[3])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[4])!==False)) and ((stripos($contenido_web_porciones[$contador],$terminos_frecuentes_ord[0])!==False) or (stripos($contenido_web_porciones[$contador],$terminos_frecuentes_ord[1])!==False) or (stripos($contenido_web_porciones[$contador],$terminos_frecuentes_ord[2])!==False) or (stripos($contenido_web_porciones[$contador],$terminos_frecuentes_ord[3])!==False) or (stripos($contenido_web_porciones[$contador],$terminos_frecuentes_ord[4])!==False))){
									?><tr>
										<td>
										<?php	echo "...";
											echo $contenido_web_porciones[$contador-2];
											echo " ";
											echo $contenido_web_porciones[$contador];
											echo " ";
											echo $contenido_web_porciones[$contador+2];
											echo " ";
											echo $contenido_web_porciones[$contador+4];
											echo "...";
											$nombre_web = mysqli_query($conexion,"SELECT Sitio from fuentes where Num='$i' ");
											$nombre_sitio = mysqli_fetch_array($nombre_web);
										?></td>
										<td>
										<?php	echo $nombre_sitio[0];
										?></td>
										
									</tr><?php
							} //Si el termino anterior y el siguiente al actual pertenecen a algunos de los terminos frecuentes buscados, se muestran
							else if( ((stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[0])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[1]) !==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[2])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[3])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[4])!==False)) and ((stripos($contenido_web_porciones[$contador+2],$terminos_frecuentes_ord[0])!==False) or (stripos($contenido_web_porciones[$contador+2],$terminos_frecuentes_ord[1])!==False) or (stripos($contenido_web_porciones[$contador+2],$terminos_frecuentes_ord[2])!==False) or (stripos($contenido_web_porciones[$contador+2],$terminos_frecuentes_ord[3])!==False) or (stripos($contenido_web_porciones[$contador+2],$terminos_frecuentes_ord[4])!==False))){
									?><tr>
										<td>
										<?php	echo "...";
											echo $contenido_web_porciones[$contador-2];
											echo " ";
											echo $contenido_web_porciones[$contador];
											echo " ";
											echo $contenido_web_porciones[$contador+2];
											echo " ";
											echo $contenido_web_porciones[$contador+4];
											echo "...";
											$nombre_web = mysqli_query($conexion,"SELECT Sitio from fuentes where Num='$i' ");
											$nombre_sitio = mysqli_fetch_array($nombre_web);
										?></td>
										<td><?php
											echo $nombre_sitio[0];
										?></td>
										
									</tr><?php
							}
							//Si el termino anterior y el siguiente del siguiente del actual estan en los terminos frecuentes, se muestran
							if( ((stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[0])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[1]) !==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[2])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[3])!==False) or (stripos($contenido_web_porciones[$contador-2],$terminos_frecuentes_ord[4])!==False)) and ((stripos($contenido_web_porciones[$contador+4],$terminos_frecuentes_ord[0])!==False) or (stripos($contenido_web_porciones[$contador+4],$terminos_frecuentes_ord[1])!==False) or (stripos($contenido_web_porciones[$contador+4],$terminos_frecuentes_ord[2])!==False) or (stripos($contenido_web_porciones[$contador+4],$terminos_frecuentes_ord[3])!==False) or (stripos($contenido_web_porciones[$contador+4],$terminos_frecuentes_ord[4])!==False))){
								?><tr>
										<td>
										<?php	echo "...";
											echo $contenido_web_porciones[$contador-2];
											echo " ";
											echo $contenido_web_porciones[$contador];
											echo " ";
											echo $contenido_web_porciones[$contador+2];
											echo " ";
											echo $contenido_web_porciones[$contador+4];
											echo "...";
											$nombre_web = mysqli_query($conexion,"SELECT Sitio from fuentes where Num='$i' ");
											$nombre_sitio = mysqli_fetch_array($nombre_web);
										?></td>
										<td><?php
											echo $nombre_sitio[0];
										?></td>
										
									</tr><?php
							}
							
						}
					
					}
					$contador = $contador + 2;
				}
				//Tener en cuenta la longitud del contenido web para saber si estamos al princio o al final
				//IF((en la posicion anterior o anterior == termino1, termino2, termino3...) && (en la posicion siguiente o siguiente == termino1,termino2,termino3...) )
				
				$i = $i + 1;
			}
						
		}	?>
			</table>
	</div>
	
	<div id="atras">
		<table>
			<tr>
				<td align=left><p class="atras"><a href="../principal.php" ><img src="../Imagenes/flecha-atras.png" ></a></p></td> 
				<td></td>				
			</tr>
		</table>
	</div>
	
	<div id="pie">
	</div>

</div>
		
</body>


</html>