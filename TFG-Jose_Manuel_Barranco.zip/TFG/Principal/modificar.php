<?php
    setlocale(LC_ALL,"es_ES"); 
    session_start();
	require_once("./session.php");
	// Establecemos la conexi�n con la base de datos
	include("../conexion.php");
	$usuario=$_SESSION['usuario'];
?>

<!DOCTYPE html>

<html>
<head>
	<title>Modificar perfil</title> <!--T�tulo de la p�gina-->
	<link rel="stylesheet" href="../estilo03.css"> <!--Para enlazar archivo css-->
	<style type="text/css" media="screen">
	</style>
</head>

<body>

<div id="contenedor"> <!--contenedor contiene toda la p�gina-->

	<div id="cabecera"> <!--Cabecera-->
	</div>

	<div id="contenido">

		<?php
		
			$pass_nuevo;
			$usuario_nuevo;
			$apellidos_nuevo;
			$nombre_nuevo;

		?>
		<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
			
			<table id="baja">
				<tr>
					<td align=right><FONT FACE="verdana"> Nombre: </td> 
					<td align=left><input type="number_format" name="nombre" size="15" value="<?php echo $_SESSION['nombre'];?>"></td>
				</tr>
				<tr>
					<td align=right><FONT FACE="verdana"> Apellidos: </td> 
					<td align=left><input type="number_format" name="apellidos" size="15" value="<?php echo $_SESSION['apellidos'];?>"></td>
				</tr>
				<tr>
					<td align=right><FONT FACE="verdana"> Usuario: </td> 
					<td align=left><input type="number_format" name="usuario" size="15" value="<?php echo $_SESSION['usuario'];?>"></td>
				</tr>
				<tr>
					<td align=right><FONT FACE="verdana"> Contrase&ntildea:  </td> 
					<td align=left><input type="password" name="contra" size="15" value="<?php echo $_SESSION['pass'];?>"></td>
				</tr>
				<tr>
					<td></td> 
					<td align=left><input type="submit" name="Modificar_datos" value="Modificar datos"></td>
				</tr>	
			</table>
			
			<br><br> 
		
		</form>
	
	</div>
	<?php 
		
	if (isset($_REQUEST['Modificar_datos']) && $_REQUEST['usuario']!='' && $_REQUEST['contra']!='' && $_REQUEST['nombre']!='' && $_REQUEST['apellidos']!='') {
		
		//ACTUALIZAMOS DATOS DE LA BD
		
		$pass_nuevo = $_REQUEST['contra'];
		$usuario_nuevo = $_REQUEST['usuario'];
		$apellidos_nuevo = $_REQUEST['apellidos'];
		$nombre_nuevo = $_REQUEST['nombre'];
		
		//Buscamos si el nombre de usuario esta ocupado
		$consulta_usuario = mysqli_query($conexion,"SELECT Nombre FROM usuarios WHERE Usuario = '$usuario_nuevo' MINUS SELECT Nombre FROM usuarios WHERE Usuario = '$usuario'");
		$rowcount_busqueda=mysqli_num_rows($consulta_usuario);
		if($rowcount_busqueda == 0){
			//Actualizamos la tabla de usuarios
			mysqli_query($conexion,"UPDATE usuarios SET Nombre ='$nombre_nuevo', Apellidos = '$apellidos_nuevo', Usuario = '$usuario_nuevo', Contrasena = '$pass_nuevo' WHERE Usuario = '$usuario'");
			
			//Actualizamos TODAS las tablas para actualizar el nombre de usuario
			mysqli_query($conexion,"UPDATE busquedas SET Usuario = '$usuario_nuevo' WHERE Usuario = '$usuario'");
			mysqli_query($conexion,"UPDATE registros SET Usuario = '$usuario_nuevo' WHERE Usuario = '$usuario'");
			
			//ACTUALIZAMOS LOS VALORES DE S_SESSION
			$_SESSION['pass'] = $pass_nuevo;
			$_SESSION['usuario'] = $usuario_nuevo;
			$_SESSION['apellidos'] = $apellidos_nuevo;
			$_SESSION['nombre'] = $nombre_nuevo;
			?><script>
				alert('Datos actualizados correctamente');
				
			</script>
			
			<?php
				header('Location: ./modificar.php'); //Redireccionamos a identificacion.php
		}
		else{
			echo "asdfasdfadfadfadfasdfadsfasdf";
			?>
			<script>
				alert('Nombre de usuario ocupado');
				
			</script><?php
		}
	}
	
		
?>	<div id="atras">
		<table>
			<tr>
				<td align=left><p class="atras"><a href="../principal.php"><img src="../Imagenes/flecha-atras.png"></a>	</a></p></td> 
				<td></td>				
			</tr>
		</table>
	</div>

	<div id="pie">
	</div>

</div>
		
</body>
</html>