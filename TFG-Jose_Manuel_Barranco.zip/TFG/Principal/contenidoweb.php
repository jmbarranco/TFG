<?php
    setlocale(LC_ALL,"es_ES"); 
    session_start();
	include("../conexion.php");
	$NombreUsuario="".$_SESSION['nombre']." ".$_SESSION['apellidos']."";
	$usuario = $_SESSION['usuario'];
	$hora = time();
	require_once("./session.php");
?>

<!DOCTYPE html>

<html>
<head>
	
	<title>SVT</title> <!--T�tulo de la p�gina-->
	
	<link rel="stylesheet" href="../estilo-principal.css"> <!--Para enlazar archivo css-->
	<style type="text/css" media="screen">
	</style>
	<script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="../js/ejercicio03.js"></script>
</head>

<body>
<div id="contenedor"> <!--contenedor contiene toda la p�gina-->

	<div id="cabecera"> <!--Cabecera-->
	</div>

	<div id="contenido">
		
		<table id="bienvenida">
			<tr>
				<td align=left><p><b> Bienvenido, <?php echo $NombreUsuario ?></b></p></td> 		
				<td align=right><i><?php echo date(" d/m/Y (H:i:s)  ", $hora); ?></i></td>
			</tr>
		</table>
		
		<table id="eleccion_sitio">
			<tr>
				<form>
							<?php
								$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes");
								$rowcount=mysqli_num_rows($paginas);
								$i = 1;
								while($i <= $rowcount){
										$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes where Num=$i");
										$paginas_vec= mysqli_fetch_array($paginas);
										
										?>
											
										<td id="eleccion_sitio" align=center><input type="radio" name="opcion" value="<?php echo $paginas_vec[0]?>" checked> <?php echo $paginas_vec[0]?></td>
									
								<?php 
									$i = $i + 1;
								}
								?>
		
		
					  <td id="eleccion_sitio"><input type="submit" id="botonEnviar" name="Seleccionar" value="Seleccionar"></td>
				</form> 
			</tr>
		</table>
		
		<?php 
		
		//Comprobamos la eleccion		
		$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes");
		$rowcount=mysqli_num_rows($paginas);
		$i = 1;
		while($i <= $rowcount){
			$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes where Num=$i");
			$paginas_vec= mysqli_fetch_array($paginas);
								
			if (isset($_REQUEST['Seleccionar'])){
				$Opcion=$_REQUEST['opcion']; 
				if($Opcion==$paginas_vec[0]){ //Con una consulta,seleccionamos el contenido web
					$cont_web = mysqli_query($conexion,"SELECT contenidoweb from fuentes where Sitio='$paginas_vec[0]'");
					$cont_web_vec = mysqli_fetch_array($cont_web);
					$texto_sin_comillas=str_replace("\"","*", $cont_web_vec[0]); //SUSTITUIMOS LAS COMILLAS POR ASTERISCOS PARA LUEGO PARSEAR LAS PALABRAS
					$texto_sin_comillas=str_replace("[","", $texto_sin_comillas); //SUSTITUIMOS LOS CORCHETES 
					$texto_sin_comillas=str_replace("]","", $texto_sin_comillas); //SUSTITUIMOS LOS CORCHETES 
					$texto_sin_comillas=str_replace(",","", $texto_sin_comillas); //SUSTITUIMOS LAS COMAS 
					$texto_sin_comillas=str_replace("u00bf","", $texto_sin_comillas); //SUSTITUIMOS LA INTERROGACION
					$texto_sin_comillas=str_replace("u201c","", $texto_sin_comillas); //SUSTITUIMOS LA COMILLA DOBLE EN CODIGO 
					$texto_sin_comillas=str_replace("u2018","", $texto_sin_comillas); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					$texto_sin_comillas=str_replace("u2019","", $texto_sin_comillas); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					$texto_sin_comillas=str_replace("u00f1","n", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00a1","", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					
					
					$texto_sin_comillas=str_replace("u00e1","a", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00e9","e", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00c9","E", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00ed","i", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00f3","o", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					$texto_sin_comillas=str_replace("u00fa","u", $texto_sin_comillas); //SUSTITUIMOS LA � EN CODIGO
					
					//Seleccionamos las palabras relevantes
					$relv_web = mysqli_query($conexion,"SELECT Novedades from fuentes where Sitio='$paginas_vec[0]'");
					$relv_web_vec = mysqli_fetch_array($relv_web);
					$texto_sin_comillas1=str_replace("\"","*", $relv_web_vec[0]); //SUSTITUIMOS LAS COMILLAS POR ASTERISCOS PARA LUEGO PARSEAR LAS PALABRAS
					$texto_sin_comillas1=str_replace("[","", $texto_sin_comillas1); //SUSTITUIMOS LOS CORCHETES 
					$texto_sin_comillas1=str_replace("]","", $texto_sin_comillas1); //SUSTITUIMOS LOS CORCHETES 
					$texto_sin_comillas1=str_replace(","," ", $texto_sin_comillas1); //SUSTITUIMOS LAS COMAS 
					$texto_sin_comillas1=str_replace("u00bf","", $texto_sin_comillas1); //SUSTITUIMOS LA INTERROGACION
					$texto_sin_comillas1=str_replace("u201c","", $texto_sin_comillas1); //SUSTITUIMOS LA COMILLA DOBLE EN CODIGO 
					$texto_sin_comillas1=str_replace("u2018","", $texto_sin_comillas1); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					$texto_sin_comillas1=str_replace("u2019","", $texto_sin_comillas1); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					
					$porciones = explode("*", $texto_sin_comillas); //Dividimos el texto cada caracter
					
					$porciones1 = explode("*", $texto_sin_comillas1); //Dividimos el texto cada caracter
							
					$cont = 0;
					$cont1 = 1;
					
					$longitud = count($porciones);
					$longitud1 = count($porciones1);
					$esta = false;
					?>
					<table id="tabla_cont_web">
						<tr>
							<td id="novedades" align=center><b> Contenido web <?php echo $Opcion ?></b></td>
						</tr>
						<tr>
							<td id ="contenido_web" align=left> 
								<?php
												while($cont < $longitud-1){
													$esta = false;
													if(empty($porciones[$cont])){//Si esta vacio, pasamos
														$cont = $cont + 1;
														
													}
													else{
														$cont1 = 1;
														while($cont1 < $longitud1-1){
															if(empty($porciones1[$cont1]))
																$cont1 = $cont1 + 2;
															else{
																$findme = $porciones1[$cont1];
																$pos = stripos($porciones[$cont], $findme);
																
																if($pos!==false){ //Esta en las relevantes
																	$esta = true;
																}
																$cont1 = $cont1 + 2;
															}	
														}
													}
													if($esta){
														?><mark><?php echo $porciones[$cont]; ?></mark> <?php
													}
													else{
														echo $porciones[$cont];
													}
													$cont = $cont + 1;
														
												}
											
												
											}
										}
										$i = $i + 1;
									}
									?>							
							</td>
						</tr>
					
					
					
					
					</table>
					
			
	</div>
	
	<div id="atras">
		<table>
			<tr>
				<td align=left><p class="atras"><a href="../principal.php" ><img src="../Imagenes/flecha-atras.png" ></a></p></td> 
				<td></td>				
			</tr>
		</table>
	</div>
	
	<div id="pie">
	</div>

</div>
		
</body>


</html>