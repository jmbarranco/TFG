<?php
    setlocale(LC_ALL,"es_ES"); 
    session_start();
	include("../conexion.php");
	$NombreUsuario="".$_SESSION['nombre']." ".$_SESSION['apellidos']."";
	$usuario = $_SESSION['usuario'];
	$hora = time();
	require_once("./session.php");
?>

<!DOCTYPE html>

<html>
<head>
	
	<title>SVT</title> <!--T�tulo de la p�gina-->
	
	<link rel="stylesheet" href="../estilo-principal.css"> <!--Para enlazar archivo css-->
	<style type="text/css" media="screen">
	</style>
	<script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
	<script type="text/javascript" src="../js/ejercicio03.js"></script>
</head>

<body>
<div id="contenedor"> <!--contenedor contiene toda la p�gina-->

	<div id="cabecera"> <!--Cabecera-->
	</div>

	<div id="contenido">
		
		<table id="bienvenida">
			<tr>
				<td align=left><p><b> Bienvenido, <?php echo $NombreUsuario ?></b></p></td> 		
				<td align=right><i><?php echo date(" d/m/Y (H:i:s)  ", $hora); ?></i></td>
			</tr>
		</table>
		
		<table id="eleccion_tendencia">
			<tr>
				<form>
					<td id="enunciado_tendencia" align=left>Sitio a actualizar:</td>
					<?php
					$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes");
					$rowcount=mysqli_num_rows($paginas);
					$i = 1;
					while($i <= $rowcount){
						$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes where Num=$i");
						$paginas_vec= mysqli_fetch_array($paginas);
					?>
					<td id="eleccion_tendencia1" align=left><input type="radio" name="opcion" value="<?php echo $paginas_vec[0]?>" checked> <?php echo $paginas_vec[0]?></td>
					<?php 
						$i = $i + 1;
					}
					?>
					<td id="enunciado_tendencia" align=center><input type="submit" id="botonactualizar" name="botonactualizar" value="Actualizar"></td>
				</form>
			</tr>
		</table>
		
		<table id="eleccion_tendencia">
			<tr>
				<form>
					<td id="enunciado_tendencia" align=left>Elija un sitio:</td>
					<?php
					$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes");
					$rowcount=mysqli_num_rows($paginas);
					$i = 1;
					while($i <= $rowcount){
						$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes where Num=$i");
						$paginas_vec= mysqli_fetch_array($paginas);
					?>
						<td id="eleccion_tendencia1" align=center><input type="radio" name="opcionbuscar" value="<?php echo $paginas_vec[0]?>" checked> <?php echo $paginas_vec[0]?></td>
					<?php 
						$i = $i + 1;
					}
					?>
					<tr>
						<td id="enunciado_tendencia" align=left> <?php echo "Introduzca una busqueda: "?></td>
						<td id="eleccion_tendencia1" align=left><input type="text" name="buscar" id="buscar" value=""></td>
						<td id="eleccion_tendencia1" align=left><input type="submit" id="botonbuscar" name="botonbuscar" value="Buscar"></td>
					</tr>
				</form> 
			</tr>
		</table>
		
		<?php 
		$paginas = mysqli_query($conexion,"SELECT Sitio from fuentes");
		$rowcount=mysqli_num_rows($paginas);
		$nombre_sitio;
		$i = 1;
		if (isset($_REQUEST['botonactualizar']) && isset($_REQUEST['opcion'])){ //Actualizamos las frecuencias de la pagina seleccionada
			while($i <= $rowcount){
				$paginas = mysqli_query($conexion,"SELECT * from fuentes where Num=$i");
				$paginas_vec= mysqli_fetch_array($paginas);
				
				if($_REQUEST['opcion'] == $paginas_vec[1]){
					$fecha=date(" d/m/Y", $hora);
					$nombre_sitio = $paginas_vec[1];
					$freq = mysqli_query($conexion,"SELECT * from frecuencias where Sitio='$paginas_vec[1]' AND Fecha='$fecha'");
					$rowcount_freq = mysqli_fetch_array($freq);
					
					//Leemos el archivo de frecuencias
					$Nombre_fichero = "../Frecuencias/frecuencias";
					$fp = fopen($Nombre_fichero.=$paginas_vec[0], "r");
					$linea = "";
					while(!feof($fp)) {
						$linea .= fgets($fp);
					}
					fclose($fp);
					
					$linea=str_replace("\u00f1","n", $linea); //Sustituimos el codigo de � por n
					$linea=str_replace("\u00bb","", $linea); //Sustituimos el codigo de >>
					$linea=str_replace("\u2014","", $linea); //Sustituimos el codigo de --				
					$linea=str_replace("\u2026","", $linea); //Sustituimos el codigo de ...
					$linea=str_replace("\u00c1","a", $linea); //Sustituimos el codigo de �
					$linea=str_replace("\u00c9","e", $linea); //Sustituimos el codigo de �
					$linea=str_replace("\u00cd","i", $linea); //Sustituimos el codigo de �
					$linea=str_replace("\u00a1","", $linea); //Sustituimos el codigo de �
					$linea=str_replace("\u00ab","", $linea); //Sustituimos el codigo de <<
					$linea=str_replace("\u00fc","u", $linea); //Sustituimos el codigo de �										
					$linea=str_replace("[","", $linea); //SUSTITUIMOS LOS CORCHETES 
					$linea=str_replace("]","", $linea); //SUSTITUIMOS LOS CORCHETES
					$linea=str_replace("\"","", $linea); //SUSTITUIMOS LAS COMILLAS DOBLES					
					$linea=str_replace(",","", $linea); //SUSTITUIMOS LAS COMAS 
					$linea=str_replace("u00bf","", $linea); //SUSTITUIMOS LA INTERROGACION
					$linea=str_replace("u201c","", $linea); //SUSTITUIMOS LA COMILLA DOBLE EN CODIGO 
					$linea=str_replace("u2018","", $linea); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
					$linea=str_replace("u2019","", $linea); //SUSTITUIMOS LA COMILLA SIMPLE EN CODIGO
																
					$linea=str_replace("u00e1","a", $linea); //SUSTITUIMOS LA � EN CODIGO
					$linea=str_replace("u00e9","e", $linea); //SUSTITUIMOS LA � EN CODIGO
					$linea=str_replace("u00ed","i", $linea); //SUSTITUIMOS LA � EN CODIGO
					$linea=str_replace("u00f3","o", $linea); //SUSTITUIMOS LA � EN CODIGO
					$linea=str_replace("u00fa","u", $linea); //SUSTITUIMOS LA � EN CODIGO
					
					if($rowcount_freq == 0){ //Si no hay nada, se inserta
						mysqli_query($conexion, "INSERT INTO frecuencias (Fecha,Sitio,Frecuencias) VALUES ('$fecha','$nombre_sitio','$linea')");
						
					}
					else{ //Hay datos ya ingresados con esa fecha y ese sitio ?>
						<script>
							alert('Los datos ya estan actualizados');
						</script> <?php
					}
					
				}
				$i = $i + 1;
			}
		}

		if((isset($_REQUEST['botonbuscar'])) && $_REQUEST['buscar']!='' && isset($_REQUEST['opcionbuscar'])){ //Buscamos un termino en las frecuencias
				
				$nombre_sitio = $_REQUEST['opcionbuscar'];
				$palabra_buscar = $_REQUEST['buscar'];
				$termino_busqueda = explode(" ", $palabra_buscar); //Dividimos el texto cada caracter
				
					$vec_fecha = array(); //Vector donde vamos a almacenar las fechas
					$vec_frecuencias = array(); //Vector donde vamos a almacenar las frecuencias del termino
					$vec_fecha1 = array(); //Vector donde vamos a almacenar las fechas
					$vec_frecuencias1 = array(); //Vector donde vamos a almacenar las frecuencias del termino
					$vec_fecha2 = array(); //Vector donde vamos a almacenar las fechas
					$vec_frecuencias2 = array(); //Vector donde vamos a almacenar las frecuencias del termino
					$esta = false;
					$esta1 = false;
					$esta2 = false;
					
					$frecuencias_fuente = mysqli_query($conexion,"SELECT * from frecuencias where Sitio='$nombre_sitio'");
					$rowcount=mysqli_num_rows($frecuencias_fuente);
					$frecuencia = mysqli_fetch_array($frecuencias_fuente);
				
					$j = 0;
					while($j<$rowcount){
						$frecuencia_string=str_replace("[","", $frecuencia[3]); //Sustituimos para convertir el array en string 
						
						$partes = explode(" ", $frecuencia_string); //Dividimos el texto por palabras
						$long_partes = count($partes);
						//echo $long_partes;
						$contador = 0;
						$esta = false;
						$esta1 = false;
						$esta2 = false;
						
						while($contador < $long_partes){ //Recorremos los terminos de las frecuencias
							//Si hay tres terminos en la busqueda o mas, SOLO SE COGEN 3
							if(count($termino_busqueda) >= 3){
								if($termino_busqueda[0]== $partes[$contador]){
									array_push($vec_frecuencias, $partes[$contador + 1]); //+1 porque la frecuencia se encuentra en la siguiente posicion
									array_push($vec_fecha,$frecuencia[1]);
									$esta = true;
								}
								if($termino_busqueda[1]== $partes[$contador]){
									array_push($vec_frecuencias1, $partes[$contador + 1]); //+1 porque la frecuencia se encuentra en la siguiente posicion
									array_push($vec_fecha1,$frecuencia[1]);
									$esta1 = true;
								}
									
								if($termino_busqueda[2]== $partes[$contador]){
									array_push($vec_frecuencias2, $partes[$contador + 1]); //+1 porque la frecuencia se encuentra en la siguiente posicion
									array_push($vec_fecha2,$frecuencia[1]);
									$esta2 = true;
								}			
							}
							//Si hay dos terminos en la busqueda 
							if(count($termino_busqueda)==2){
								if($termino_busqueda[0]== $partes[$contador]){
										array_push($vec_frecuencias, $partes[$contador + 1]); //+1 porque la frecuencia se encuentra en la siguiente posicion
										array_push($vec_fecha,$frecuencia[1]);
										$esta = true;
								}
								
								if($termino_busqueda[1]== $partes[$contador]){
									array_push($vec_frecuencias1, $partes[$contador + 1]); //+1 porque la frecuencia se encuentra en la siguiente posicion
									array_push($vec_fecha1,$frecuencia[1]);
									$esta1 = true;
								}
							}
							// Si solo hay un termino en la busqueda..
							if(count($termino_busqueda) == 1){
								if($termino_busqueda[0]== $partes[$contador]){
										array_push($vec_frecuencias, $partes[$contador + 1]); //+1 porque la frecuencia se encuentra en la siguiente posicion
										array_push($vec_fecha,$frecuencia[1]);
										$esta = true;
								}
							}
							$contador = $contador + 2; //De dos en dos puesto que el termino se almacena en las posiciones pares
						}
						if($esta==false){ //Si no esta, a�adimos 0 a frecuencias
							array_push($vec_frecuencias, 0); 
							array_push($vec_fecha,$frecuencia[1]);
						}
						if($esta1==false){ //Si no esta, a�adimos 0 a frecuencias
							array_push($vec_frecuencias1, 0); 
							array_push($vec_fecha1,$frecuencia[1]);
						}
						if($esta2==false){ //Si no esta, a�adimos 0 a frecuencias
							array_push($vec_frecuencias2, 0); 
							array_push($vec_fecha2,$frecuencia[1]);
						}
						$frecuencia = mysqli_fetch_array($frecuencias_fuente); //Para actualizar en caso de que haya mas de una fila
						$j = $j + 1;
					}
				
			//Dibujamos la grafica
				?>
				<table id="muestra_busqueda">
					<tr>
						<td>Mostrando tendencia de la palabra: <?php if(count($termino_busqueda)>=3){
																		echo $termino_busqueda[0];
																		echo " ";
																		echo $termino_busqueda[1];
																		echo " ";
																		echo $termino_busqueda[2];
																	}
																	if(count($termino_busqueda)==2){
																		echo $termino_busqueda[0];
																		echo " ";
																		echo $termino_busqueda[1];
																	}
																	if(count($termino_busqueda)==1){
																		echo $termino_busqueda[0];
																	}
																		?> </td>
					</tr>
				</table>
				
			<script src="../Chart.js/Chart.js"></script>
				<div id="canvas-holder">
					<canvas id="chart-area4" width="600" height="300"></canvas>
				</div>
			<script>
				var datos = [] ;
				var etiquetas = [];
				var datos1 = [] ;
				var etiquetas1 = [];
				var datos2 = [] ;
				var etiquetas2 = [];
				<?php //Si hay tres o mas terminos en la busqueda, almacenamos el nombre en una variable javascript para la grafica
				if(count($termino_busqueda) >= 3){?>
					var termino = "<?php echo $termino_busqueda[0]?>";
					var termino1 = "<?php echo $termino_busqueda[1]?>";
					var termino2 = "<?php echo $termino_busqueda[2]?>";
				<?php
				}
				//Si hay dos terminos en la busqueda, almacenamos el nombre en variables javascript
				if(count($termino_busqueda) == 2){?>
					var termino = "<?php echo $termino_busqueda[0]?>";
					var termino1 = "<?php echo $termino_busqueda[1]?>";
					var termino2 = " ";
				<?php
				}
				//Si solo hay un termino en la busqueda, almacenamos su nombre en una variable javascript
				if(count($termino_busqueda) == 1){?>
					var termino = "<?php echo $termino_busqueda[0]?>";
					var termino1 = " ";
					var termino2 = " ";
				<?php
				}
				
					$longitud_frecuencias = count($vec_frecuencias);
					$k = 0;
					//Si hay tres terminos o mas, lo almacenamos la frecuencia en vectores de javascript para la grafica
					if(count($termino_busqueda)>=3){
						while($k < $longitud_frecuencias){
							?>	datos.push("<?php echo $vec_frecuencias[$k]?>");
								datos1.push("<?php echo $vec_frecuencias1[$k]?>");
								datos2.push("<?php echo $vec_frecuencias2[$k]?>");
							
						<?php $k = $k + 1;
						}
					}
					//Si hay dos terminos, almacenamos las frecuencias en vectores de javascript
					if(count($termino_busqueda)==2){
						while($k < $longitud_frecuencias){
							?>	datos.push("<?php echo $vec_frecuencias[$k]?>");
								datos1.push("<?php echo $vec_frecuencias1[$k]?>");
							
						<?php $k = $k + 1;
						}
					}
					//Si hay un solo termino, almacenamos las frecuencias en vector de javascript
					if(count($termino_busqueda)==1){
						while($k < $longitud_frecuencias){
							?>	datos.push("<?php echo $vec_frecuencias[$k]?>");
													
						<?php $k = $k + 1;
						}
					}
					
					$longitud_fecha = count($vec_fecha);
					$k = 0;
					//Si hay tres o mas terminos, almacenamos las fechas para la grafica en vector javascript
					if(count($termino_busqueda) >= 3){
						while($k < $longitud_fecha){
							?>	etiquetas.push("<?php echo $vec_fecha[$k]?>");
							etiquetas1.push("<?php echo $vec_fecha1[$k]?>");
							etiquetas2.push("<?php echo $vec_fecha2[$k]?>");
							
						<?php $k = $k + 1;
						}
					}
					//Si hay dos terminos en la busqueda, almacenamos las fechas en vectores javascript
					if(count($termino_busqueda) == 2){
						while($k < $longitud_fecha){
							?>	etiquetas.push("<?php echo $vec_fecha[$k]?>");
							etiquetas1.push("<?php echo $vec_fecha1[$k]?>");
							
						<?php $k = $k + 1;
						}
					}
					// Si solo hay un termino, almacenar las fechas en un vector javascript
					if(count($termino_busqueda) == 1){
						while($k < $longitud_fecha){
							?>	etiquetas.push("<?php echo $vec_fecha[$k]?>");					
						<?php $k = $k + 1;
						}
					}
				
				
				?>
				
						var lineChartData = {
							
							labels : etiquetas,
							datasets : [
								{
									label: termino,
									fillColor : "rgba(220,220,220,0.4)",
									strokeColor : "#6b9dfa",
									pointColor : "#1e45d7",
									pointStrokeColor : "#000",
									pointHighlightFill : "#000",
									pointHighlightStroke : "rgba(220,220,220,1)",
									data : datos
								},
								{
									label: termino1,
									fillColor : "rgba(255,204,84,0.2)",
									strokeColor : "#ffcc54",
									pointColor : "#ffcc54",
									pointStrokeColor : "#000",
									pointHighlightFill : "#000",
									pointHighlightStroke : "rgba(255,204,84,1)",
									data : datos1
								},
								{
									label: termino2,
									fillColor : "rgba(151,242,166,0.2)",
									strokeColor : "#97f2a6",
									pointColor : "#97f2a6",
									pointStrokeColor : "#000",
									pointHighlightFill : "#000",
									pointHighlightStroke : "rgba(151,242,166,1)",
									data : datos2
								}
							]

						}
				var ctx4 = document.getElementById("chart-area4").getContext("2d");
				window.myPie = new Chart(ctx4).Line(lineChartData, {responsive:true});
			</script>
		
	<?php	} ?>


	</div>
	
	<div id="atras">
		<table>
			<tr>
				<td align=left><p class="atras"><a href="../principal.php" ><img src="../Imagenes/flecha-atras.png" ></a></p></td> 
				<td></td>				
			</tr>
		</table>
	</div>
	
	<div id="pie">
	</div>

</div>
		
</body>


</html>